package com.cart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingCartServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
